import Link from "next/link"

const Navigation = () => {
  return (
    <nav className="bg-navy text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          製造業×生成AI コンサルティング
        </Link>
        <ul className="flex space-x-4">
          <li>
            <Link href="/services">サービス</Link>
          </li>
          <li>
            <Link href="/case-studies">導入事例</Link>
          </li>
          <li>
            <Link href="/blog">ブログ</Link>
          </li>
          <li>
            <Link href="/about">会社概要</Link>
          </li>
          <li>
            <Link href="/contact" className="bg-orange text-navy px-4 py-2 rounded">
              お問い合わせ
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default Navigation

