import Link from "next/link"

const Footer = () => {
  return (
    <footer className="bg-navy text-white p-4 mt-8">
      <div className="container mx-auto flex justify-between items-center">
        <div>
          <p>&copy; 2023 製造業×生成AI コンサルティング</p>
        </div>
        <ul className="flex space-x-4">
          <li>
            <Link href="/privacy-policy">プライバシーポリシー</Link>
          </li>
          <li>
            <Link href="/terms-of-service">利用規約</Link>
          </li>
        </ul>
      </div>
    </footer>
  )
}

export default Footer

