import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <section className="py-12">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">製造業×生成AIで、現場の課題を解決する経営コンサル</h1>
          <p className="text-xl mb-8">技術と経営の知見を活かし、AIで製造業の未来を創造します</p>
          <Image
            src="/hero-image.jpg"
            alt="製造現場とAI技術のイメージ"
            width={1200}
            height={600}
            className="rounded-lg shadow-lg mb-8"
          />
          <Link href="/contact" className="bg-orange text-navy px-6 py-3 rounded-lg text-xl font-bold">
            無料相談を申し込む
          </Link>
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">主なサービス</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">生成AI導入・運用支援</h3>
            <p>製造現場に最適な生成AIソリューションを提案し、導入から運用までサポートします。</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">経営支援サービス</h3>
            <p>製造業に特化したコンサルティングで、経営課題の解決と業績向上を支援します。</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">資格試験対策講座</h3>
            <p>中小企業診断士や技術系資格の対策講座を提供し、キャリアアップを支援します。</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">選ばれる理由</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">製造業×AI×経営の専門知識</h3>
            <p>20年以上のエンジニア経験とMBA資格を持つ専門家が、技術と経営の両面からサポートします。</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">オーダーメイドのソリューション</h3>
            <p>お客様の課題に合わせて、最適なAIソリューションと経営戦略を提案します。</p>
          </div>
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">お問い合わせ</h2>
        <div className="text-center">
          <p className="mb-4">まずは無料相談で、あなたの課題をお聞かせください。</p>
          <Link href="/contact" className="bg-orange text-navy px-6 py-3 rounded-lg text-xl font-bold">
            無料相談を申し込む
          </Link>
        </div>
      </section>
    </div>
  )
}

