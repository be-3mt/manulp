import "./globals.css"
import type { Metadata } from "next"
import { Noto_Sans_JP } from "next/font/google"
import Navigation from "./components/Navigation"
import Footer from "./components/Footer"
import type React from "react" // Added import for React

const notoSansJP = Noto_Sans_JP({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "製造業×生成AI 経営コンサルティング",
  description: "製造業の現場課題を生成AIと経営の知見で解決します。",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ja">
      <body className={notoSansJP.className}>
        <Navigation />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}

